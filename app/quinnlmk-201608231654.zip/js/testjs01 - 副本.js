function add2 (aaa,bbb) {
     return aaa+bbb; 
}